import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import Header from "../components/Header";
import BottomNav from "../components/BottomNav";
import ProfileCard from "../components/ProfileCard";

export default function Dashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const getUser = async () => {
      const { data } = await supabase.auth.getUser();
      setUser(data.user);
    };
    getUser();
  }, []);

  return (
    <div className="bg-green-50 h-screen flex flex-col">
      <Header />
      <div className="p-4 flex-1">
        {user ? <ProfileCard user={user} /> : "Loading..."}
      </div>
      <BottomNav />
    </div>
  );
}