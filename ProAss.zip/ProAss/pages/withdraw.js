import { useState } from "react";
import { supabase } from "../lib/supabaseClient";
import Header from "../components/Header";
import BottomNav from "../components/BottomNav";

export default function Withdraw() {
  const [account, setAccount] = useState("");
  const [number, setNumber] = useState("");
  const [name, setName] = useState("");

  const requestWithdraw = async () => {
    const { data: { user } } = await supabase.auth.getUser();

    const { error } = await supabase.from("withdrawals").insert({
      user_id: user.id,
      account,
      number,
      name,
      status: "pending",
    });

    if (!error) {
      alert("Withdrawal request submitted!");
      setAccount(""); setNumber(""); setName("");
    } else {
      alert("Error: " + error.message);
    }
  };

  return (
    <div className="h-screen bg-green-50 flex flex-col">
      <Header />
      <div className="p-4 flex-1">
        <h2 className="text-xl font-bold text-green-700 mb-4">Withdraw</h2>
        <input
          type="text"
          placeholder="Account Type (JazzCash/Easypaisa/Bank)"
          className="p-2 border w-full rounded mb-2"
          value={account}
          onChange={(e) => setAccount(e.target.value)}
        />
        <input
          type="text"
          placeholder="Number"
          className="p-2 border w-full rounded mb-2"
          value={number}
          onChange={(e) => setNumber(e.target.value)}
        />
        <input
          type="text"
          placeholder="Account Holder Name"
          className="p-2 border w-full rounded mb-2"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <button
          onClick={requestWithdraw}
          className="w-full bg-green-600 text-white py-2 rounded"
        >
          Submit
        </button>
      </div>
      <BottomNav />
    </div>
  );
}