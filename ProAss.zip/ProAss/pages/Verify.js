import { useState } from "react";
import { supabase } from "../lib/supabaseClient";
import Header from "../components/Header";
import BottomNav from "../components/BottomNav";

export default function Verify() {
  const [file, setFile] = useState(null);

  const uploadProof = async () => {
    const { data: { user } } = await supabase.auth.getUser();

    if (!file) return alert("Please select a file!");

    const filePath = `${user.id}/${Date.now()}-${file.name}`;

    const { error: uploadError } = await supabase.storage
      .from("verifications")
      .upload(filePath, file);

    if (uploadError) {
      alert("Upload failed: " + uploadError.message);
      return;
    }

    const { data: { publicUrl } } = supabase.storage
      .from("verifications")
      .getPublicUrl(filePath);

    await supabase.from("verifications").insert({
      user_id: user.id,
      screenshot_url: publicUrl,
      status: "pending",
    });

    alert("Verification submitted! Waiting for admin approval.");
    setFile(null);
  };

  return (
    <div className="h-screen bg-green-50 flex flex-col">
      <Header />
      <div className="p-4 flex-1">
        <h2 className="text-xl font-bold text-green-700 mb-4">Verify Account</h2>
        <input
          type="file"
          className="mb-2"
          onChange={(e) => setFile(e.target.files[0])}
        />
        <button
          onClick={uploadProof}
          className="w-full bg-green-600 text-white py-2 rounded"
        >
          Upload Proof
        </button>
      </div>
      <BottomNav />
    </div>
  );
}