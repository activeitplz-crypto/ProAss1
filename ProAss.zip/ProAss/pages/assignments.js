import { useState } from "react";
import { supabase } from "../lib/supabaseClient";
import Header from "../components/Header";
import BottomNav from "../components/BottomNav";

export default function Assignments() {
  const [title, setTitle] = useState("");
  const [urls, setUrls] = useState([""]);

  const addAssignment = async () => {
    const { data: { user } } = await supabase.auth.getUser();

    const insertData = {
      user_id: user.id,
      title,
      url1: urls[0] || null,
      url2: urls[1] || null,
      url3: urls[2] || null,
      url4: urls[3] || null,
      url5: urls[4] || null,
      url6: urls[5] || null,
    };

    await supabase.from("assignments").insert(insertData);

    // update balance
    await supabase.rpc("increment_balance", { uid: user.id });
    alert("Assignment added! +1000 balance");
  };

  return (
    <div className="h-screen bg-green-50 flex flex-col">
      <Header />
      <div className="p-4 flex-1">
        <input
          type="text"
          placeholder="Assignment Title"
          className="p-2 border w-full rounded mb-2"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        {urls.map((url, idx) => (
          <input
            key={idx}
            type="url"
            placeholder={`URL ${idx + 1}`}
            className="p-2 border w-full rounded mb-2"
            value={url}
            onChange={(e) => {
              const newUrls = [...urls];
              newUrls[idx] = e.target.value;
              setUrls(newUrls);
            }}
          />
        ))}
        {urls.length < 6 && (
          <button
            onClick={() => setUrls([...urls, ""])}
            className="bg-green-500 text-white px-2 py-1 rounded mb-2"
          >
            + Add URL
          </button>
        )}
        <button
          onClick={addAssignment}
          className="w-full bg-green-600 text-white py-2 rounded"
        >
          Submit Assignment
        </button>
      </div>
      <BottomNav />
    </div>
  );
}