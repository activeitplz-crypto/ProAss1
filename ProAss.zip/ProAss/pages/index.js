import { useState } from "react";
import { supabase } from "../lib/supabaseClient";
import { useRouter } from "next/router";

export default function Home() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [isSignup, setIsSignup] = useState(false);
  const router = useRouter();

  const handleAuth = async () => {
    if (isSignup) {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { name },
        },
      });
      if (!error) router.push("/dashboard");
    } else {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (!error) router.push("/dashboard");
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-green-50">
      <h1 className="text-3xl font-bold text-green-700">Pro Assignments</h1>
      {isSignup && (
        <input
          type="text"
          placeholder="Name"
          className="p-2 border rounded mt-2"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      )}
      <input
        type="email"
        placeholder="Email"
        className="p-2 border rounded mt-2"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        className="p-2 border rounded mt-2"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button
        onClick={handleAuth}
        className="mt-4 bg-green-600 text-white px-4 py-2 rounded"
      >
        {isSignup ? "Sign Up" : "Login"}
      </button>
      <p
        onClick={() => setIsSignup(!isSignup)}
        className="mt-4 text-green-600 cursor-pointer"
      >
        {isSignup ? "Already have an account? Login" : "New user? Sign Up"}
      </p>
    </div>
  );
}