import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";

export default function ProfileCard({ user: initialUser }) {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  // Accept either:
  // - `initialUser` is the Supabase `user` object (from supabase.auth.getUser())
  // - or nothing (component will fetch current auth user)
  useEffect(() => {
    let mounted = true;
    async function fetchProfile() {
      setLoading(true);
      try {
        let userId = null;
        if (initialUser) {
          // try different shapes
          userId = initialUser.id || initialUser?.user?.id || initialUser?.data?.id;
        } else {
          const { data } = await supabase.auth.getUser();
          userId = data?.user?.id;
        }
        if (!userId) {
          if (mounted) setProfile(null);
          return;
        }

        // Fetch app-specific user row from 'users' table (has total_earning, current_balance, assignments_count, dp_url, verified)
        const { data, error } = await supabase
          .from("users")
          .select("id, name, email, dp_url, total_earning, current_balance, assignments_count, verified")
          .eq("id", userId)
          .single();

        if (error) {
          // If row doesn't exist, try to build a minimal profile from auth user metadata
          const { data: authData } = await supabase.auth.getUser();
          const authUser = authData?.user;
          if (authUser && mounted) {
            setProfile({
              id: authUser.id,
              name: authUser.user_metadata?.name || authUser.email?.split("@")[0],
              email: authUser.email,
              dp_url: authUser.user_metadata?.avatar_url || null,
              total_earning: 0,
              current_balance: 0,
              assignments_count: 0,
              verified: authUser.user_metadata?.verified || false,
            });
          }
        } else {
          if (mounted) setProfile(data);
        }
      } catch (err) {
        console.error("Profile load error:", err);
        if (mounted) setProfile(null);
      } finally {
        if (mounted) setLoading(false);
      }
    }

    fetchProfile();
    return () => {
      mounted = false;
    };
  }, [initialUser]);

  if (loading) {
    return <div className="bg-white p-4 rounded-xl shadow">Loading profile…</div>;
  }

  if (!profile) {
    return (
      <div className="bg-white p-4 rounded-xl shadow">
        <p className="text-gray-600">No profile found. Please login.</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-4 rounded-xl shadow">
      <div className="flex items-center gap-4">
        <img
          src={profile.dp_url || "https://via.placeholder.com/80"}
          alt="profile"
          className="w-16 h-16 rounded-full object-cover"
        />
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-semibold">{profile.name || "User"}</h2>
            {profile.verified && (
              <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded">✔ Verified</span>
            )}
          </div>
          <p className="text-sm text-gray-500">{profile.email}</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 mt-4 text-center">
        <div>
          <div className="text-xs text-gray-500">Total Earning</div>
          <div className="font-semibold">{profile.total_earning ?? 0}</div>
        </div>
        <div>
          <div className="text-xs text-gray-500">Current Balance</div>
          <div className="font-semibold">{profile.current_balance ?? 0}</div>
        </div>
        <div>
          <div className="text-xs text-gray-500">Assignments</div>
          <div className="font-semibold">{profile.assignments_count ?? 0}</div>
        </div>
      </div>
    </div>
  );
}