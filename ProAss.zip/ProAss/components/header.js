import { useRouter } from "next/router";
import { supabase } from "../lib/supabaseClient";

export default function Header() {
  const router = useRouter();

  const logout = async () => {
    await supabase.auth.signOut();
    router.push("/");
  };

  return (
    <div className="flex justify-between items-center bg-green-600 p-4 text-white">
      <div className="flex items-center gap-2">
        <img
          src="https://i.postimg.cc/4NycZngc/In-Shot-20250828-122821151.png"
          alt="logo"
          className="w-8 h-8"
        />
        <h1 className="text-lg font-bold">Pro Assignments</h1>
      </div>
      <div className="flex gap-4">
        <button onClick={() => router.push("/verify")}>Verify</button>
        <button onClick={logout}>Logout</button>
      </div>
    </div>
  );
}