import { useRouter } from "next/router";

export default function BottomNav() {
  const router = useRouter();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-md flex justify-around p-3 md:hidden">
      <button
        onClick={() => router.push("/dashboard")}
        className="flex flex-col items-center text-sm"
        aria-label="Home"
      >
        <span className="text-lg">🏠</span>
        <span>Home</span>
      </button>

      <button
        onClick={() => router.push("/assignments")}
        className="flex flex-col items-center text-sm"
        aria-label="Assignments"
      >
        <span className="text-lg">📁</span>
        <span>Assignments</span>
      </button>

      <button
        onClick={() => router.push("/withdraw")}
        className="flex flex-col items-center text-sm"
        aria-label="Withdraw"
      >
        <span className="text-lg">💸</span>
        <span>Withdraw</span>
      </button>
    </nav>
  );
}